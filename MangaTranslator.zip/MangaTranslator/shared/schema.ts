import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: text("created_at").notNull(),
});

export const mangaProjects = pgTable("manga_projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("uploaded"), // uploaded, processing, translated, completed
  createdAt: text("created_at").notNull(),
});

export const mangaPages = pgTable("manga_pages", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  filename: text("filename").notNull(),
  originalImageUrl: text("original_image_url").notNull(),
  translatedImageUrl: text("translated_image_url"),
  ocrText: jsonb("ocr_text"), // Array of text blocks with positions
  translations: jsonb("translations"), // Array of translated text blocks
  status: text("status").notNull().default("uploaded"), // uploaded, ocr_processed, translated, overlay_applied
});

export const insertMangaProjectSchema = createInsertSchema(mangaProjects).omit({
  id: true,
  createdAt: true,
});

export const insertMangaPageSchema = createInsertSchema(mangaPages).omit({
  id: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export type InsertMangaProject = z.infer<typeof insertMangaProjectSchema>;
export type MangaProject = typeof mangaProjects.$inferSelect;
export type InsertMangaPage = z.infer<typeof insertMangaPageSchema>;
export type MangaPage = typeof mangaPages.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
