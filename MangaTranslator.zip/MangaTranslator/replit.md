# AI Manga Translator - Puter.js Edition

## Overview

This is a full-stack web application for AI-powered manga translation using Puter.js for OCR and translation capabilities. The application allows users to upload manga pages, extract text using OCR, translate the text to different languages, and apply translated text overlays back onto the images.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend and backend:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: React hooks with TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Canvas Operations**: Custom canvas utilities for image manipulation and text overlay

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Database**: PostgreSQL with Drizzle ORM
- **Development**: Vite for development server and hot module replacement
- **API**: REST API structure (routes currently minimal)

## Key Components

### Core Features
1. **File Upload System**: Drag-and-drop interface for manga page uploads
2. **OCR Processing**: Integration with Puter.js AI services for text extraction
3. **Translation Engine**: AI-powered translation with multiple language support
4. **Text Overlay System**: Canvas-based text rendering over original images
5. **Export Functionality**: Download processed images with translations

### Database Schema
- **manga_projects**: Project management with status tracking
- **manga_pages**: Individual page data including OCR results and translations
- **Status Tracking**: Multi-stage workflow (uploaded → processing → translated → completed)

### AI Integration
- **Puter.js Client**: Wrapper for Puter.js AI services
- **OCR Capabilities**: Text extraction with bounding box coordinates
- **Translation Models**: Support for multiple AI models (GPT-4o, Claude 3.5 Sonnet, etc.)
- **Multi-language Support**: Auto-detection and translation between various languages

## Data Flow

1. **Upload Phase**: Users upload manga images via drag-and-drop interface
2. **OCR Phase**: Images are processed through Puter.js OCR to extract text blocks with positions
3. **Translation Phase**: Extracted text is translated using AI models with configurable styles
4. **Overlay Phase**: Translated text is rendered back onto images using canvas operations
5. **Export Phase**: Final images are made available for download

## External Dependencies

### Primary Dependencies
- **Puter.js**: AI services for OCR and translation (loaded via CDN)
- **Neon Database**: PostgreSQL hosting solution
- **Radix UI**: Accessible component primitives
- **TanStack Query**: Server state management and caching

### Development Tools
- **Vite**: Build tool and development server
- **Drizzle Kit**: Database migrations and schema management
- **TypeScript**: Type safety and developer experience

## Deployment Strategy

The application is configured for deployment with:

### Build Process
- Frontend builds to `dist/public` using Vite
- Backend bundles to `dist` using esbuild
- Production start script serves both frontend and API

### Environment Configuration
- Database URL required via environment variables
- Development and production mode differentiation
- Replit-specific integrations for development environment

### Database Management
- Drizzle migrations in `./migrations` directory
- Schema definitions in `shared/schema.ts`
- Push-based deployment with `db:push` command

## Changelog

```
Changelog:
- July 01, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```