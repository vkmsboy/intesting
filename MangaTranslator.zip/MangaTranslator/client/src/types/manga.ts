export interface TextBlock {
  id: string;
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
}

export interface TranslatedTextBlock extends TextBlock {
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
}

export interface MangaImage {
  id: string;
  file: File;
  url: string;
  name: string;
  size: number;
  status: 'uploaded' | 'processing' | 'ocr_complete' | 'translated' | 'overlay_applied';
  textBlocks: TextBlock[];
  translatedBlocks: TranslatedTextBlock[];
  overlayUrl?: string;
}

export interface TranslationSettings {
  sourceLanguage: string;
  targetLanguage: string;
  aiModel: string;
  translationStyle: string;
}

export interface ProcessingStatus {
  currentStep: number;
  totalSteps: number;
  currentOperation: string;
  progress: number;
}

export type WorkflowStep = 'upload' | 'extract' | 'translate' | 'overlay' | 'export';

export interface PuterOCRResult {
  text: string;
  confidence: number;
  blocks?: Array<{
    text: string;
    bbox: [number, number, number, number];
    confidence: number;
  }>;
}

export interface PuterTranslationResult {
  message: {
    content: string;
  };
}
