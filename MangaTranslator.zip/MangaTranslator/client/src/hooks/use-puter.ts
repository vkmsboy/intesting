import { useState, useCallback } from 'react';
import { puterClient } from '@/lib/puter-client';
import { TextBlock, TranslatedTextBlock } from '@/types/manga';
import { CanvasUtils } from '@/lib/canvas-utils';
import { useToast } from '@/hooks/use-toast';

export function usePuter() {
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const extractTextFromImage = useCallback(async (file: File): Promise<TextBlock[]> => {
    if (!puterClient.isAvailable()) {
      toast({
        title: "Error",
        description: "Puter.js is not available. Please refresh the page.",
        variant: "destructive",
      });
      throw new Error('Puter.js not available');
    }

    setIsProcessing(true);
    try {
      const result = await puterClient.extractText(file);
      const textBlocks = CanvasUtils.parseOCRResult(result);
      
      toast({
        title: "OCR Complete",
        description: `Extracted ${textBlocks.length} text blocks from ${file.name}`,
      });
      
      return textBlocks;
    } catch (error) {
      toast({
        title: "OCR Failed",
        description: error.message || "Failed to extract text from image",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [toast]);

  const translateTextBlocks = useCallback(async (
    textBlocks: TextBlock[],
    sourceLanguage: string,
    targetLanguage: string,
    model: string = 'gpt-4o',
    style: string = 'natural'
  ): Promise<TranslatedTextBlock[]> => {
    if (!puterClient.isAvailable()) {
      toast({
        title: "Error",
        description: "Puter.js is not available. Please refresh the page.",
        variant: "destructive",
      });
      throw new Error('Puter.js not available');
    }

    setIsProcessing(true);
    try {
      const translatedBlocks: TranslatedTextBlock[] = [];

      for (const block of textBlocks) {
        try {
          const result = await puterClient.translateText(
            block.text,
            sourceLanguage,
            targetLanguage,
            model,
            style
          );

          translatedBlocks.push({
            ...block,
            translatedText: result.message?.content || result.text || block.text,
            sourceLanguage,
            targetLanguage,
          });
        } catch (error) {
          console.warn(`Failed to translate block ${block.id}:`, error);
          // Keep original text if translation fails
          translatedBlocks.push({
            ...block,
            translatedText: block.text,
            sourceLanguage,
            targetLanguage,
          });
        }
      }

      toast({
        title: "Translation Complete",
        description: `Translated ${translatedBlocks.length} text blocks`,
      });

      return translatedBlocks;
    } catch (error) {
      toast({
        title: "Translation Failed",
        description: error.message || "Failed to translate text",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [toast]);

  const translateSingleText = useCallback(async (
    text: string,
    sourceLanguage: string,
    targetLanguage: string,
    model: string = 'gpt-4o',
    style: string = 'natural'
  ): Promise<string> => {
    if (!puterClient.isAvailable()) {
      throw new Error('Puter.js not available');
    }

    try {
      const result = await puterClient.translateText(
        text,
        sourceLanguage,
        targetLanguage,
        model,
        style
      );

      return result.message?.content || result.text || text;
    } catch (error) {
      console.warn('Translation failed:', error);
      return text; // Return original text if translation fails
    }
  }, []);

  return {
    extractTextFromImage,
    translateTextBlocks,
    translateSingleText,
    isProcessing,
    isAvailable: puterClient.isAvailable(),
  };
}
