declare global {
  interface Window {
    puter: {
      ai: {
        img2txt: (source: File | string, testMode?: boolean) => Promise<string>;
        chat: (message: string, options?: any) => Promise<any>;
      };
    };
  }
}

export class PuterClient {
  private static instance: PuterClient;

  public static getInstance(): PuterClient {
    if (!PuterClient.instance) {
      PuterClient.instance = new PuterClient();
    }
    return PuterClient.instance;
  }

  async extractText(file: File): Promise<any> {
    if (!window.puter) {
      throw new Error('Puter.js is not loaded. Please ensure the script is included.');
    }

    if (!window.puter.ai || !window.puter.ai.img2txt) {
      throw new Error('Puter.js AI img2txt function not available. Please check your connection.');
    }

    console.log('Starting OCR extraction for file:', file.name, 'Size:', file.size);

    try {
      // Convert File to data URL for Puter.js
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      console.log('Converting file to data URL for Puter.js');
      
      // Use the correct img2txt function with data URL
      const extractedText = await window.puter.ai.img2txt(dataUrl);
      console.log('OCR result (text):', extractedText);
      
      // Convert the text result to the expected format for our app
      return {
        text: extractedText,
        confidence: 0.9, // Default confidence since Puter.js doesn't provide this
        blocks: [{
          text: extractedText,
          bbox: [50, 50, 300, 100], // Default bounding box
          confidence: 0.9
        }]
      };
    } catch (error) {
      console.error('OCR extraction failed:', error);
      
      // Provide more specific error messages
      const errorMessage = error instanceof Error ? error.message : String(error);
      if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
        throw new Error('Network error: Please check your internet connection and try again.');
      } else if (errorMessage.includes('unauthorized') || errorMessage.includes('403')) {
        throw new Error('Authentication error: Puter.js services may require user authentication.');
      } else if (errorMessage.includes('rate limit') || errorMessage.includes('429')) {
        throw new Error('Rate limit exceeded: Please wait a moment before trying again.');
      } else {
        throw new Error(`OCR failed: ${errorMessage || 'Unknown error occurred'}`);
      }
    }
  }

  async translateText(
    text: string,
    sourceLanguage: string,
    targetLanguage: string,
    model: string = 'gpt-4o',
    style: string = 'natural'
  ): Promise<any> {
    if (!window.puter) {
      throw new Error('Puter.js is not loaded. Please ensure the script is included.');
    }

    const styleInstructions = {
      natural: 'Translate this text naturally and conversationally, maintaining the tone and context.',
      literal: 'Provide a literal, word-for-word translation while keeping it readable.',
      localized: 'Translate this text with cultural localization and context adaptation.'
    };

    const instruction = styleInstructions[style as keyof typeof styleInstructions] || styleInstructions.natural;
    const prompt = `${instruction}\n\nTranslate from ${sourceLanguage} to ${targetLanguage}:\n\n${text}`;

    try {
      const result = await window.puter.ai.chat(prompt, {
        model: model
      });
      return result;
    } catch (error) {
      console.error('Translation failed:', error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to translate text: ${errorMessage || 'Unknown error'}`);
    }
  }

  async translateTextStream(
    text: string,
    sourceLanguage: string,
    targetLanguage: string,
    model: string = 'gpt-4o',
    style: string = 'natural',
    onChunk?: (chunk: string) => void
  ): Promise<string> {
    if (!window.puter) {
      throw new Error('Puter.js is not loaded. Please ensure the script is included.');
    }

    const styleInstructions = {
      natural: 'Translate this text naturally and conversationally, maintaining the tone and context.',
      literal: 'Provide a literal, word-for-word translation while keeping it readable.',
      localized: 'Translate this text with cultural localization and context adaptation.'
    };

    const instruction = styleInstructions[style as keyof typeof styleInstructions] || styleInstructions.natural;
    const prompt = `${instruction}\n\nTranslate from ${sourceLanguage} to ${targetLanguage}:\n\n${text}`;

    try {
      const response = await window.puter.ai.chat(prompt, {
        model: model,
        stream: true
      });

      let fullResponse = '';
      
      for await (const part of response) {
        const chunk = part.text || '';
        fullResponse += chunk;
        if (onChunk) {
          onChunk(chunk);
        }
      }

      return fullResponse;
    } catch (error) {
      console.error('Streaming translation failed:', error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to translate text: ${errorMessage || 'Unknown error'}`);
    }
  }

  private fileToDataUrl(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  isAvailable(): boolean {
    return typeof window !== 'undefined' && !!window.puter;
  }
}

export const puterClient = PuterClient.getInstance();
