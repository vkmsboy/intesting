import { TextBlock, TranslatedTextBlock } from '@/types/manga';

export class CanvasUtils {
  static createImageFromFile(file: File): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = URL.createObjectURL(file);
    });
  }

  static drawTextOverlay(
    canvas: HTMLCanvasElement,
    image: HTMLImageElement,
    translatedBlocks: TranslatedTextBlock[]
  ): void {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size to match image
    canvas.width = image.width;
    canvas.height = image.height;

    // Draw the original image
    ctx.drawImage(image, 0, 0);

    // Draw translated text overlays
    translatedBlocks.forEach((block) => {
      const { x, y, width, height, translatedText } = block;

      // Create background for text
      ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
      ctx.fillRect(x, y, width, height);

      // Add border
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.2)';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, width, height);

      // Calculate font size based on text block height
      const fontSize = Math.min(height * 0.3, 16);
      ctx.font = `${fontSize}px Inter, Arial, sans-serif`;
      ctx.fillStyle = '#000000';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // Wrap text if it's too long
      const words = translatedText.split(' ');
      const lines = this.wrapText(ctx, words.join(' '), width - 8);
      
      // Draw each line
      const lineHeight = fontSize * 1.2;
      const totalHeight = lines.length * lineHeight;
      const startY = y + (height - totalHeight) / 2 + lineHeight / 2;

      lines.forEach((line, index) => {
        ctx.fillText(
          line,
          x + width / 2,
          startY + index * lineHeight
        );
      });
    });
  }

  static wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
    const words = text.split(' ');
    const lines: string[] = [];
    let currentLine = '';

    for (const word of words) {
      const testLine = currentLine + (currentLine ? ' ' : '') + word;
      const metrics = ctx.measureText(testLine);
      
      if (metrics.width > maxWidth && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }
    
    if (currentLine) {
      lines.push(currentLine);
    }
    
    return lines;
  }

  static drawTextBoundingBoxes(
    canvas: HTMLCanvasElement,
    image: HTMLImageElement,
    textBlocks: TextBlock[]
  ): void {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size to match image
    canvas.width = image.width;
    canvas.height = image.height;

    // Draw the original image
    ctx.drawImage(image, 0, 0);

    // Draw bounding boxes
    textBlocks.forEach((block, index) => {
      const { x, y, width, height } = block;

      // Draw bounding box
      ctx.strokeStyle = '#FCD34D';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, height);

      // Draw semi-transparent overlay
      ctx.fillStyle = 'rgba(252, 211, 77, 0.2)';
      ctx.fillRect(x, y, width, height);

      // Draw label
      const label = `Text ${index + 1}`;
      const labelHeight = 20;
      const labelY = y > labelHeight ? y - 2 : y + height + 2;
      
      ctx.fillStyle = '#FCD34D';
      ctx.fillRect(x, labelY - labelHeight, 60, labelHeight);
      
      ctx.fillStyle = '#000000';
      ctx.font = '12px Inter, Arial, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, x + 4, labelY - labelHeight / 2);
    });
  }

  static downloadCanvasAsImage(canvas: HTMLCanvasElement, filename: string): void {
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    });
  }

  static parseOCRResult(ocrResult: any): TextBlock[] {
    // Handle different OCR result formats from Puter.js
    const textBlocks: TextBlock[] = [];
    
    if (ocrResult.blocks && Array.isArray(ocrResult.blocks)) {
      // Format with detailed bounding boxes
      ocrResult.blocks.forEach((block: any, index: number) => {
        if (block.bbox && block.text) {
          const [x1, y1, x2, y2] = block.bbox;
          textBlocks.push({
            id: `block-${index}`,
            text: block.text,
            x: x1,
            y: y1,
            width: x2 - x1,
            height: y2 - y1,
            confidence: block.confidence || 0.9
          });
        }
      });
    } else if (ocrResult.text) {
      // Simple text result - create a single block
      textBlocks.push({
        id: 'block-0',
        text: ocrResult.text,
        x: 50,
        y: 50,
        width: 200,
        height: 50,
        confidence: ocrResult.confidence || 0.9
      });
    }
    
    return textBlocks;
  }
}
