import { useState, useCallback, useEffect } from 'react';
import { ProgressSteps } from '@/components/ui/progress-steps';
import { UploadSection } from '@/components/manga/upload-section';
import { SettingsPanel } from '@/components/manga/settings-panel';
import { ImageGallery } from '@/components/manga/image-gallery';
import { PreviewCanvas } from '@/components/manga/preview-canvas';
import { TextTranslationPanel } from '@/components/manga/text-translation-panel';
import { ExportPanel } from '@/components/manga/export-panel';
import { usePuter } from '@/hooks/use-puter';
import { useToast } from '@/hooks/use-toast';
import { MangaImage, TranslationSettings, WorkflowStep, TranslatedTextBlock } from '@/types/manga';
import { Languages, Zap, AlertCircle } from 'lucide-react';

export default function MangaTranslator() {
  const [images, setImages] = useState<MangaImage[]>([]);
  const [activeImageId, setActiveImageId] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<WorkflowStep>('upload');
  const [showOriginal, setShowOriginal] = useState(true);
  const [puterStatus, setPuterStatus] = useState<'loading' | 'connected' | 'error'>('loading');
  const [settings, setSettings] = useState<TranslationSettings>({
    sourceLanguage: 'ja',
    targetLanguage: 'en',
    aiModel: 'gpt-4o',
    translationStyle: 'natural',
  });

  const { extractTextFromImage, translateTextBlocks, isProcessing } = usePuter();
  const { toast } = useToast();

  // Monitor Puter.js status
  useEffect(() => {
    let lastStatus = '';
    
    const checkPuterStatus = () => {
      if (typeof window !== 'undefined') {
        let newStatus = '';
        if (window.puter && window.puter.ai && typeof window.puter.ai.img2txt === 'function') {
          newStatus = 'connected';
          setPuterStatus('connected');
        } else if (window.puter && window.puter.ai) {
          newStatus = 'error';
          setPuterStatus('error');
        } else if (window.puter) {
          newStatus = 'error';
          setPuterStatus('error');
        }
        
        // Only log when status changes
        if (newStatus !== lastStatus && newStatus) {
          console.log('Puter.js status:', newStatus);
          lastStatus = newStatus;
        }
      }
    };

    // Check immediately
    checkPuterStatus();

    // Check periodically but less frequently
    const interval = setInterval(checkPuterStatus, 3000);

    // Check after a delay to allow script loading
    setTimeout(checkPuterStatus, 5000);

    return () => clearInterval(interval);
  }, []);

  const activeImage = images.find(img => img.id === activeImageId) || null;

  const handleFilesAccepted = useCallback((files: File[]) => {
    const newImages: MangaImage[] = files.map(file => ({
      id: crypto.randomUUID(),
      file,
      url: URL.createObjectURL(file),
      name: file.name,
      size: file.size,
      status: 'uploaded',
      textBlocks: [],
      translatedBlocks: [],
    }));

    setImages(prev => [...prev, ...newImages]);
    
    // Set first image as active if none selected
    if (!activeImageId && newImages.length > 0) {
      setActiveImageId(newImages[0].id);
    }

    if (currentStep === 'upload') {
      setCurrentStep('extract');
    }

    toast({
      title: "Files Uploaded",
      description: `Added ${newImages.length} manga page${newImages.length > 1 ? 's' : ''}`,
    });
  }, [activeImageId, currentStep, toast]);

  const handleRemoveImage = useCallback((imageId: string) => {
    setImages(prev => prev.filter(img => img.id !== imageId));
    if (activeImageId === imageId) {
      setActiveImageId(images.find(img => img.id !== imageId)?.id || null);
    }
  }, [activeImageId, images]);

  const handleStartOCR = useCallback(async () => {
    if (!activeImage) {
      toast({
        title: "No Image Selected",
        description: "Please select an image to extract text from",
        variant: "destructive",
      });
      return;
    }

    if (puterStatus !== 'connected') {
      toast({
        title: "Puter.js Not Available",
        description: "Please wait for Puter.js to load, or try using demo data below",
        variant: "destructive",
      });
      return;
    }

    try {
      setImages(prev => prev.map(img => 
        img.id === activeImageId 
          ? { ...img, status: 'processing' }
          : img
      ));

      console.log('Starting OCR for image:', activeImage.name);
      const textBlocks = await extractTextFromImage(activeImage.file);
      console.log('OCR completed, extracted blocks:', textBlocks);
      
      setImages(prev => prev.map(img => 
        img.id === activeImageId 
          ? { ...img, textBlocks, status: 'ocr_complete' }
          : img
      ));

      setCurrentStep('translate');
    } catch (error) {
      console.error('OCR failed:', error);
      setImages(prev => prev.map(img => 
        img.id === activeImageId 
          ? { ...img, status: 'uploaded' }
          : img
      ));
    }
  }, [activeImage, activeImageId, extractTextFromImage, toast, puterStatus]);

  const handleStartTranslation = useCallback(async () => {
    if (!activeImage || activeImage.textBlocks.length === 0) {
      toast({
        title: "No Text Extracted",
        description: "Please run OCR first to extract text",
        variant: "destructive",
      });
      return;
    }

    try {
      setImages(prev => prev.map(img => 
        img.id === activeImageId 
          ? { ...img, status: 'processing' }
          : img
      ));

      const translatedBlocks = await translateTextBlocks(
        activeImage.textBlocks,
        settings.sourceLanguage,
        settings.targetLanguage,
        settings.aiModel,
        settings.translationStyle
      );

      setImages(prev => prev.map(img => 
        img.id === activeImageId 
          ? { ...img, translatedBlocks, status: 'translated' }
          : img
      ));

      setCurrentStep('overlay');
      setShowOriginal(false);
    } catch (error) {
      setImages(prev => prev.map(img => 
        img.id === activeImageId 
          ? { ...img, status: 'ocr_complete' }
          : img
      ));
    }
  }, [activeImage, activeImageId, translateTextBlocks, settings, toast]);

  const handleUpdateTranslation = useCallback((blockId: string, newTranslation: string) => {
    if (!activeImageId) return;

    setImages(prev => prev.map(img => 
      img.id === activeImageId
        ? {
            ...img,
            translatedBlocks: img.translatedBlocks.map(block =>
              block.id === blockId
                ? { ...block, translatedText: newTranslation }
                : block
            )
          }
        : img
    ));
  }, [activeImageId]);

  const handleRetranslateAll = useCallback(async () => {
    if (!activeImage) return;
    await handleStartTranslation();
  }, [activeImage, handleStartTranslation]);

  const handleApplyOverlay = useCallback(() => {
    if (!activeImageId) return;

    setImages(prev => prev.map(img => 
      img.id === activeImageId 
        ? { ...img, status: 'overlay_applied' }
        : img
    ));

    setCurrentStep('export');
    setShowOriginal(false);

    toast({
      title: "Overlay Applied",
      description: "Text overlay has been applied to the image",
    });
  }, [activeImageId, toast]);

  const handleDownload = useCallback(() => {
    if (!activeImage) return;

    const canvas = document.createElement('canvas');
    const image = new Image();
    
    image.onload = () => {
      // This would use CanvasUtils to create the final image
      const filename = `${activeImage.name.split('.')[0]}_translated.png`;
      // CanvasUtils.downloadCanvasAsImage(canvas, filename);
      
      toast({
        title: "Download Started",
        description: `Downloading ${filename}`,
      });
    };
    
    image.src = activeImage.url;
  }, [activeImage, toast]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Languages className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-gray-900">AI Manga Translator</h1>
              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                Powered by Puter.js
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-500">
                <span className="font-medium">Puter.js:</span>
                <span className={`ml-1 ${
                  puterStatus === 'connected' ? 'text-success' : 
                  puterStatus === 'error' ? 'text-error' : 'text-warning'
                }`}>
                  {puterStatus === 'connected' ? 'Connected' : 
                   puterStatus === 'error' ? 'Error' : 'Loading...'}
                </span>
              </div>
              {puterStatus === 'error' && <AlertCircle className="w-4 h-4 text-error" />}
              <Zap className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Steps */}
        <div className="mb-8">
          <ProgressSteps currentStep={currentStep} />
        </div>

        {/* Main Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Panel - Upload & Controls */}
          <div className="lg:col-span-4 space-y-6">
            <UploadSection
              images={images}
              onFilesAccepted={handleFilesAccepted}
              onRemoveImage={handleRemoveImage}
              isProcessing={isProcessing}
            />

            <SettingsPanel
              settings={settings}
              onSettingsChange={setSettings}
              onStartOCR={handleStartOCR}
              onStartTranslation={handleStartTranslation}
              canStartOCR={!!activeImage && activeImage.status === 'uploaded'}
              canStartTranslation={!!activeImage && activeImage.textBlocks.length > 0}
              isProcessing={isProcessing}
            />
          </div>

          {/* Right Panel - Image Gallery & Preview */}
          <div className="lg:col-span-8 space-y-6">
            <ImageGallery
              images={images}
              activeImageId={activeImageId}
              onImageSelect={setActiveImageId}
              onAddMore={() => document.getElementById('file-input')?.click()}
            />

            <PreviewCanvas
              activeImage={activeImage}
              showOriginal={showOriginal}
              onToggleView={() => setShowOriginal(!showOriginal)}
              onDownload={handleDownload}
            />

            <TextTranslationPanel
              translatedBlocks={activeImage?.translatedBlocks || []}
              onUpdateTranslation={handleUpdateTranslation}
              onRetranslateAll={handleRetranslateAll}
              onApplyOverlay={handleApplyOverlay}
              isProcessing={isProcessing}
            />

            <ExportPanel
              images={images}
              activeImage={activeImage}
              onExportSingle={handleDownload}
              onExportBatch={() => toast({ title: "Coming Soon", description: "Batch export feature coming soon!" })}
              onExportPDF={() => toast({ title: "Coming Soon", description: "PDF export feature coming soon!" })}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Powered by{' '}
              <a href="https://puter.com" className="text-primary hover:underline">
                Puter.js
              </a>{' '}
              • Free OCR & AI Translation
            </div>
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <span>Cost: $0.00</span>
              <span>•</span>
              <span>Pages Processed: {images.filter(img => img.status !== 'uploaded').length}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
