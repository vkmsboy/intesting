import { cn } from '@/lib/utils';
import { WorkflowStep } from '@/types/manga';

interface ProgressStepsProps {
  currentStep: WorkflowStep;
  className?: string;
}

const steps: { key: WorkflowStep; label: string; number: number }[] = [
  { key: 'upload', label: 'Upload', number: 1 },
  { key: 'extract', label: 'Extract Text', number: 2 },
  { key: 'translate', label: 'Translate', number: 3 },
  { key: 'overlay', label: 'Overlay', number: 4 },
  { key: 'export', label: 'Export', number: 5 },
];

export function ProgressSteps({ currentStep, className }: ProgressStepsProps) {
  const currentStepIndex = steps.findIndex(step => step.key === currentStep);

  return (
    <div className={cn("flex items-center justify-between", className)}>
      <div className="flex items-center space-x-4">
        {steps.map((step, index) => (
          <div key={step.key} className="flex items-center space-x-2">
            <div
              className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium",
                index <= currentStepIndex
                  ? "bg-primary text-white"
                  : "bg-gray-300 text-gray-600"
              )}
            >
              {step.number}
            </div>
            <span
              className={cn(
                "text-sm font-medium",
                index <= currentStepIndex ? "text-gray-900" : "text-gray-500"
              )}
            >
              {step.label}
            </span>
            {index < steps.length - 1 && (
              <div
                className={cn(
                  "w-16 h-px ml-4",
                  index < currentStepIndex ? "bg-primary" : "bg-gray-300"
                )}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
