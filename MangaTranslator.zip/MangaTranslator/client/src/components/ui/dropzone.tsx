import { useCallback } from 'react';
import { cn } from '@/lib/utils';
import { Upload } from 'lucide-react';

interface DropzoneProps {
  onFilesAccepted: (files: File[]) => void;
  accept?: string;
  maxFiles?: number;
  className?: string;
  children?: React.ReactNode;
  disabled?: boolean;
}

export function Dropzone({
  onFilesAccepted,
  accept = ".jpg,.jpeg,.png",
  maxFiles = 10,
  className,
  children,
  disabled = false,
}: DropzoneProps) {
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (disabled) return;

    const files = Array.from(e.dataTransfer.files);
    const validFiles = files.filter(file => {
      const validTypes = accept.split(',').map(type => type.trim().replace('.', ''));
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      return fileExtension && validTypes.includes(fileExtension);
    });

    if (validFiles.length > maxFiles) {
      validFiles.splice(maxFiles);
    }

    if (validFiles.length > 0) {
      onFilesAccepted(validFiles);
    }
  }, [onFilesAccepted, accept, maxFiles, disabled]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;

    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      onFilesAccepted(files.slice(0, maxFiles));
    }
    // Reset input value to allow same file selection
    e.target.value = '';
  }, [onFilesAccepted, maxFiles, disabled]);

  return (
    <div
      className={cn(
        "border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary hover:bg-blue-50 transition-colors cursor-pointer",
        disabled && "opacity-50 cursor-not-allowed hover:border-gray-300 hover:bg-transparent",
        className
      )}
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDrop={handleDrop}
      onClick={() => !disabled && document.getElementById('file-input')?.click()}
    >
      {children || (
        <div className="space-y-3">
          <div className="mx-auto w-12 h-12 text-gray-400">
            <Upload className="w-full h-full" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">Drop manga images here</p>
            <p className="text-xs text-gray-500">or click to browse</p>
          </div>
          <div className="text-xs text-gray-400">
            Supports JPG, PNG • Max 10MB per file
          </div>
        </div>
      )}
      <input
        id="file-input"
        type="file"
        className="hidden"
        multiple
        accept={accept}
        onChange={handleFileInput}
        disabled={disabled}
      />
    </div>
  );
}
