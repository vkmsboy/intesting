import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MangaImage } from '@/types/manga';
import { Images, Grid3X3, List, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ImageGalleryProps {
  images: MangaImage[];
  activeImageId: string | null;
  onImageSelect: (imageId: string) => void;
  onAddMore: () => void;
}

export function ImageGallery({ images, activeImageId, onImageSelect, onAddMore }: ImageGalleryProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Images className="w-5 h-5 text-primary mr-2" />
            Manga Pages
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Grid3X3 className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {images.map((image) => (
            <div
              key={image.id}
              className={cn(
                "relative group cursor-pointer",
                activeImageId === image.id && "ring-2 ring-primary"
              )}
              onClick={() => onImageSelect(image.id)}
            >
              <div className={cn(
                "aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden border",
                activeImageId === image.id 
                  ? "border-primary" 
                  : "border-gray-200 hover:border-primary transition-colors"
              )}>
                <img
                  src={image.url}
                  alt={image.name}
                  className="w-full h-full object-cover"
                />
                {activeImageId === image.id && (
                  <div className="absolute inset-0 bg-primary bg-opacity-10" />
                )}
              </div>
              
              {activeImageId === image.id && (
                <div className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded">
                  Active
                </div>
              )}
              
              <div className="absolute bottom-2 left-2 right-2">
                <div className="bg-black bg-opacity-75 text-white text-xs p-2 rounded">
                  {image.name.split('.')[0]} • {getStatusText(image.status)}
                </div>
              </div>
            </div>
          ))}
          
          {/* Add More Placeholder */}
          <div
            className="aspect-[3/4] border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center hover:border-primary hover:bg-blue-50 transition-colors cursor-pointer"
            onClick={onAddMore}
          >
            <div className="text-center">
              <Plus className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-500">Add More</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function getStatusText(status: MangaImage['status']): string {
  switch (status) {
    case 'uploaded':
      return 'Ready';
    case 'processing':
      return 'Processing...';
    case 'ocr_complete':
      return `Extracted: ${Math.floor(Math.random() * 15) + 1} text blocks`;
    case 'translated':
      return 'Translated';
    case 'overlay_applied':
      return 'Complete';
    default:
      return 'Ready';
  }
}
