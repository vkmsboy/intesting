import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { TranslationSettings } from '@/types/manga';
import { Settings, Eye, Languages } from 'lucide-react';

interface SettingsPanelProps {
  settings: TranslationSettings;
  onSettingsChange: (settings: TranslationSettings) => void;
  onStartOCR: () => void;
  onStartTranslation: () => void;
  canStartOCR: boolean;
  canStartTranslation: boolean;
  isProcessing: boolean;
}

const languages = [
  { value: 'auto', label: 'Auto-detect' },
  { value: 'ja', label: 'Japanese' },
  { value: 'ko', label: 'Korean' },
  { value: 'zh', label: 'Chinese' },
  { value: 'en', label: 'English' },
  { value: 'es', label: 'Spanish' },
  { value: 'fr', label: 'French' },
  { value: 'de', label: 'German' },
  { value: 'pt', label: 'Portuguese' },
  { value: 'it', label: 'Italian' },
];

const aiModels = [
  { value: 'gpt-4o', label: 'GPT-4o (Recommended)' },
  { value: 'claude-3-5-sonnet', label: 'Claude 3.5 Sonnet' },
  { value: 'gpt-4.5', label: 'GPT-4.5 (Preview)' },
  { value: 'deepseek-r1', label: 'DeepSeek-R1' },
];

const translationStyles = [
  { value: 'natural', label: 'Natural & Conversational' },
  { value: 'literal', label: 'Literal Translation' },
  { value: 'localized', label: 'Localized & Cultural' },
];

export function SettingsPanel({
  settings,
  onSettingsChange,
  onStartOCR,
  onStartTranslation,
  canStartOCR,
  canStartTranslation,
  isProcessing,
}: SettingsPanelProps) {
  const updateSetting = (key: keyof TranslationSettings, value: string) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Settings className="w-5 h-5 text-primary mr-2" />
          Translation Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="source-language" className="text-sm font-medium text-gray-700">
            Source Language
          </Label>
          <Select
            value={settings.sourceLanguage}
            onValueChange={(value) => updateSetting('sourceLanguage', value)}
          >
            <SelectTrigger className="w-full mt-2">
              <SelectValue placeholder="Select source language" />
            </SelectTrigger>
            <SelectContent>
              {languages.map((lang) => (
                <SelectItem key={lang.value} value={lang.value}>
                  {lang.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="target-language" className="text-sm font-medium text-gray-700">
            Target Language
          </Label>
          <Select
            value={settings.targetLanguage}
            onValueChange={(value) => updateSetting('targetLanguage', value)}
          >
            <SelectTrigger className="w-full mt-2">
              <SelectValue placeholder="Select target language" />
            </SelectTrigger>
            <SelectContent>
              {languages.filter(lang => lang.value !== 'auto').map((lang) => (
                <SelectItem key={lang.value} value={lang.value}>
                  {lang.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="ai-model" className="text-sm font-medium text-gray-700">
            AI Model
          </Label>
          <Select
            value={settings.aiModel}
            onValueChange={(value) => updateSetting('aiModel', value)}
          >
            <SelectTrigger className="w-full mt-2">
              <SelectValue placeholder="Select AI model" />
            </SelectTrigger>
            <SelectContent>
              {aiModels.map((model) => (
                <SelectItem key={model.value} value={model.value}>
                  {model.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="translation-style" className="text-sm font-medium text-gray-700">
            Translation Style
          </Label>
          <Select
            value={settings.translationStyle}
            onValueChange={(value) => updateSetting('translationStyle', value)}
          >
            <SelectTrigger className="w-full mt-2">
              <SelectValue placeholder="Select translation style" />
            </SelectTrigger>
            <SelectContent>
              {translationStyles.map((style) => (
                <SelectItem key={style.value} value={style.value}>
                  {style.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3 pt-4">
          <Button
            onClick={onStartOCR}
            disabled={!canStartOCR || isProcessing}
            className="w-full"
          >
            <Eye className="w-4 h-4 mr-2" />
            Extract Text (OCR)
          </Button>
          <Button
            onClick={onStartTranslation}
            disabled={!canStartTranslation || isProcessing}
            className="w-full bg-success hover:bg-green-600"
          >
            <Languages className="w-4 h-4 mr-2" />
            Translate Text
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
