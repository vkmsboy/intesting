import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { TranslatedTextBlock } from '@/types/manga';
import { MessageSquare, Edit, RefreshCw, Layers } from 'lucide-react';
import { useState } from 'react';

interface TextTranslationPanelProps {
  translatedBlocks: TranslatedTextBlock[];
  onUpdateTranslation: (blockId: string, newTranslation: string) => void;
  onRetranslateAll: () => void;
  onApplyOverlay: () => void;
  isProcessing: boolean;
}

export function TextTranslationPanel({
  translatedBlocks,
  onUpdateTranslation,
  onRetranslateAll,
  onApplyOverlay,
  isProcessing,
}: TextTranslationPanelProps) {
  const [editingBlock, setEditingBlock] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  const handleEdit = (block: TranslatedTextBlock) => {
    setEditingBlock(block.id);
    setEditText(block.translatedText);
  };

  const handleSave = (blockId: string) => {
    onUpdateTranslation(blockId, editText);
    setEditingBlock(null);
    setEditText('');
  };

  const handleCancel = () => {
    setEditingBlock(null);
    setEditText('');
  };

  if (translatedBlocks.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MessageSquare className="w-5 h-5 text-primary mr-2" />
            Extracted Text & Translations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            No text blocks extracted yet. Upload images and run OCR to get started.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <MessageSquare className="w-5 h-5 text-primary mr-2" />
          Extracted Text & Translations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {translatedBlocks.map((block, index) => (
          <div key={block.id} className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-yellow-600">
                Text Block {index + 1}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleEdit(block)}
                disabled={editingBlock === block.id || isProcessing}
              >
                <Edit className="w-3 h-3 mr-1" />
                Edit
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                  Original ({getLanguageName(block.sourceLanguage)})
                </Label>
                <div className="text-sm text-gray-900 bg-gray-50 p-2 rounded mt-1">
                  {block.text}
                </div>
              </div>
              
              <div>
                <Label className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                  Translation ({getLanguageName(block.targetLanguage)})
                </Label>
                {editingBlock === block.id ? (
                  <div className="space-y-2 mt-1">
                    <Textarea
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      className="text-sm"
                      rows={3}
                    />
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        onClick={() => handleSave(block.id)}
                      >
                        Save
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleCancel}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-gray-900 bg-blue-50 p-2 rounded mt-1">
                    {block.translatedText}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        
        {/* Batch Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <div className="text-sm text-gray-600">
            {translatedBlocks.length} text blocks extracted • {translatedBlocks.filter(b => b.translatedText !== b.text).length} translated
          </div>
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={onRetranslateAll}
              disabled={isProcessing}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Re-translate All
            </Button>
            <Button
              onClick={onApplyOverlay}
              disabled={isProcessing || translatedBlocks.filter(b => b.translatedText !== b.text).length === 0}
            >
              <Layers className="w-4 h-4 mr-2" />
              Apply Overlay
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function getLanguageName(code: string): string {
  const languages: Record<string, string> = {
    'auto': 'Auto-detect',
    'ja': 'Japanese',
    'ko': 'Korean',
    'zh': 'Chinese',
    'en': 'English',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'pt': 'Portuguese',
    'it': 'Italian',
  };
  return languages[code] || code;
}
