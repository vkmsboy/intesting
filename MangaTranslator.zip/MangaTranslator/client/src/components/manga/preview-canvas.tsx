import { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MangaImage } from '@/types/manga';
import { CanvasUtils } from '@/lib/canvas-utils';
import { Eye, EyeOff, Edit, Download } from 'lucide-react';

interface PreviewCanvasProps {
  activeImage: MangaImage | null;
  showOriginal: boolean;
  onToggleView: () => void;
  onDownload: () => void;
}

export function PreviewCanvas({ activeImage, showOriginal, onToggleView, onDownload }: PreviewCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [showBoundingBoxes, setShowBoundingBoxes] = useState(true);

  useEffect(() => {
    if (!activeImage || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const image = new Image();
    
    image.onload = () => {
      if (showOriginal || activeImage.translatedBlocks.length === 0) {
        // Show original with bounding boxes if OCR is complete
        if (activeImage.textBlocks.length > 0 && showBoundingBoxes) {
          CanvasUtils.drawTextBoundingBoxes(canvas, image, activeImage.textBlocks);
        } else {
          // Just show the original image
          canvas.width = image.width;
          canvas.height = image.height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(image, 0, 0);
          }
        }
      } else {
        // Show with translation overlay
        CanvasUtils.drawTextOverlay(canvas, image, activeImage.translatedBlocks);
      }
    };
    
    image.src = activeImage.url;
  }, [activeImage, showOriginal, showBoundingBoxes]);

  if (!activeImage) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Preview & Edit</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96 flex items-center justify-center text-gray-500">
            Select an image to preview
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Preview & Edit</CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              variant={showOriginal ? "default" : "outline"}
              size="sm"
              onClick={onToggleView}
            >
              Original
            </Button>
            <Button
              variant={!showOriginal ? "default" : "outline"}
              size="sm"
              onClick={onToggleView}
              disabled={activeImage.translatedBlocks.length === 0}
            >
              With Translation
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <div className="relative bg-gray-100 rounded-lg overflow-hidden" style={{ maxHeight: '600px' }}>
            <canvas
              ref={canvasRef}
              className="w-full h-auto object-contain"
              style={{ maxHeight: '600px' }}
            />
          </div>
          
          {/* Overlay Controls */}
          <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-3 space-y-2">
            {activeImage.textBlocks.length > 0 && showOriginal && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowBoundingBoxes(!showBoundingBoxes)}
                className="flex items-center space-x-2 text-sm"
              >
                {showBoundingBoxes ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                <span>Toggle Boxes</span>
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 text-sm"
            >
              <Edit className="w-4 h-4" />
              <span>Edit Text</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onDownload}
              className="flex items-center space-x-2 text-sm"
            >
              <Download className="w-4 h-4" />
              <span>Export</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
