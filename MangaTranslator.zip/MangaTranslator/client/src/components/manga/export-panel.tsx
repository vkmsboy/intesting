import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MangaImage } from '@/types/manga';
import { Download, FileImage, FileArchive, FileText } from 'lucide-react';
import { CanvasUtils } from '@/lib/canvas-utils';

interface ExportPanelProps {
  images: MangaImage[];
  activeImage: MangaImage | null;
  onExportSingle: () => void;
  onExportBatch: () => void;
  onExportPDF: () => void;
}

export function ExportPanel({ 
  images, 
  activeImage, 
  onExportSingle, 
  onExportBatch, 
  onExportPDF 
}: ExportPanelProps) {
  const handleExportSingle = async () => {
    if (!activeImage) return;

    try {
      const canvas = document.createElement('canvas');
      const image = new Image();
      
      image.onload = () => {
        if (activeImage.translatedBlocks.length > 0) {
          CanvasUtils.drawTextOverlay(canvas, image, activeImage.translatedBlocks);
        } else {
          canvas.width = image.width;
          canvas.height = image.height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(image, 0, 0);
          }
        }
        
        const filename = `${activeImage.name.split('.')[0]}_translated.png`;
        CanvasUtils.downloadCanvasAsImage(canvas, filename);
      };
      
      image.src = activeImage.url;
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const handleExportBatch = async () => {
    // For demo purposes, this would create a ZIP file with all translated images
    console.log('Batch export not yet implemented');
    onExportBatch();
  };

  const handleExportPDF = async () => {
    // For demo purposes, this would create a PDF with all translated pages
    console.log('PDF export not yet implemented');
    onExportPDF();
  };

  const hasTranslatedImages = images.some(img => img.translatedBlocks.length > 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Download className="w-5 h-5 text-primary mr-2" />
          Export Options
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            variant="outline"
            className="p-4 h-auto flex-col space-y-2 hover:border-primary hover:bg-blue-50 transition-colors"
            onClick={handleExportSingle}
            disabled={!activeImage}
          >
            <FileImage className="w-8 h-8 text-gray-400 group-hover:text-primary" />
            <div className="text-center">
              <div className="text-sm font-medium text-gray-900">Single Image</div>
              <div className="text-xs text-gray-500">Download current page</div>
            </div>
          </Button>
          
          <Button
            variant="outline"
            className="p-4 h-auto flex-col space-y-2 hover:border-primary hover:bg-blue-50 transition-colors"
            onClick={handleExportBatch}
            disabled={!hasTranslatedImages}
          >
            <FileArchive className="w-8 h-8 text-gray-400 group-hover:text-primary" />
            <div className="text-center">
              <div className="text-sm font-medium text-gray-900">Batch ZIP</div>
              <div className="text-xs text-gray-500">All pages as archive</div>
            </div>
          </Button>
          
          <Button
            variant="outline"
            className="p-4 h-auto flex-col space-y-2 hover:border-primary hover:bg-blue-50 transition-colors"
            onClick={handleExportPDF}
            disabled={!hasTranslatedImages}
          >
            <FileText className="w-8 h-8 text-gray-400 group-hover:text-primary" />
            <div className="text-center">
              <div className="text-sm font-medium text-gray-900">PDF Document</div>
              <div className="text-xs text-gray-500">Combined as PDF</div>
            </div>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
