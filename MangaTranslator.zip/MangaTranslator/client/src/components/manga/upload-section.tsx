import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dropzone } from '@/components/ui/dropzone';
import { Button } from '@/components/ui/button';
import { MangaImage } from '@/types/manga';
import { Upload, Check, X } from 'lucide-react';

interface UploadSectionProps {
  images: MangaImage[];
  onFilesAccepted: (files: File[]) => void;
  onRemoveImage: (id: string) => void;
  isProcessing: boolean;
}

export function UploadSection({ images, onFilesAccepted, onRemoveImage, isProcessing }: UploadSectionProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Upload className="w-5 h-5 text-primary mr-2" />
          Upload Manga Pages
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Dropzone 
          onFilesAccepted={onFilesAccepted}
          disabled={isProcessing}
        />
        
        {images.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-700">Uploaded Files</h4>
            {images.map((image) => (
              <div key={image.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded flex items-center justify-center">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                  <span className="text-sm text-gray-700">{image.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-500">{formatBytes(image.size)}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveImage(image.id)}
                    disabled={isProcessing}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
